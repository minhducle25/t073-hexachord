import React, { useEffect, useState } from 'react';
import { categorizedPositions } from '../NoteMap';
import Notes from '../Chords/Notes';

// Utility function to convert MIDI number to note name without octave
const midiToNote = (midiNumber) => {
  const notes = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  return notes[midiNumber % 12];
};

const Connector = ({ notes, isPlaying }) => {
  const [renderedNotes, setRenderedNotes] = useState([]);

  useEffect(() => {
    if (isPlaying) {
      const newRenderedNotes = notes.map(note => {
        console.log('Note:', note); // Debug: Log the note
        const noteName = midiToNote(note.pitch);
        console.log('Note name:', noteName); // Debug: Log the note name
        const positions = categorizedPositions[noteName];
        console.log('Positions for pitch:', noteName, positions); // Debug: Log the positions for the pitch
        const position = positions ? positions.find(pos => pos.note === noteName) : null;
        console.log('Position found:', position); // Debug: Log the found position
        return {
          ...note,
          x: position ? position.x : 0,
          y: position ? position.y : 0,
          noteName: noteName,
          className: 'test-render', // Add your desired class name here
        };
      });
      console.log('Rendered Notes:', newRenderedNotes); // Debug: Log the rendered notes array
      setRenderedNotes(newRenderedNotes);
    } else {
      setRenderedNotes([]);
    }
  }, [notes, isPlaying]);

  return (
    <svg>
      {renderedNotes.map((note, index) => (
        <Notes
          key={index}
          cx={note.x}
          cy={note.y}
          r={10}
          note={note.pitch}
          onNoteClick={() => {}}
          onNoteRelease={() => {}}
          selectedNote={note.noteName} // Set the selected note to the note name
          className="test-render" // Pass the className to the Notes component
        />
      ))}
    </svg>
  );
};

export default Connector;